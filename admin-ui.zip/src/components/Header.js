import React from "react";
import { Box } from "@mui/material";

const Header = () => {
  return (
    <Box className="header">
      <Box>Admin UI</Box>
    </Box>
  );
};

export default Header;
