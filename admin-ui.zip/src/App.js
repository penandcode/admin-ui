import Dashboard from "./components/Dashboard";
import "./components/style.css"

function App() {
  return (
    <div className="App">
      <Dashboard/>
    </div>
  );
}

export default App;
